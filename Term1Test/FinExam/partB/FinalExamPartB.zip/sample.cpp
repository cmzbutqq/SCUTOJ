#include <iostream>
#include <iomanip>

#include <string>
#include <vector>
#include <map>
#include <set>
#include <algorithm>

#include <cmath>
#include <memory> //unique_ptr shared_ptr

using namespace std;

int main()
{
    int custom;
    while (cin >> custom)
    { // main loop
      // input

        // input /
        // test area

        // test area /
    } // main loop /
    return 0;
}
